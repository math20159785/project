<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo e(config('app.name', 'Laravel')); ?> @ <?php echo e(date('Y')); ?></span>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\mkta-database\resources\views/common/footer.blade.php ENDPATH**/ ?>