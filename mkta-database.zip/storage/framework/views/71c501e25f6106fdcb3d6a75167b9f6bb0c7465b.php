<!-- App core JavaScript-->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('admin/js/sb-admin-2.min.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\mkta-database\resources\views/auth/includes/scripts.blade.php ENDPATH**/ ?>